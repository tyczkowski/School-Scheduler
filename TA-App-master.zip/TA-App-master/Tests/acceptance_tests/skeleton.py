class Project:
	def command(userString): #userString is what the user typed on the command line
		return "" #the return value will be the applications response